class painting:
    def __init__(self,paintingID,painterName,paintingPice,paintingType):
        self.paintingId,self.painterName,self.paintingPrice,self.paintingType=paintingID,painterName,paintingPice,paintingType


class ShowRoom:
    def __init__(self,paintingObjectslist):
        self.paintinglist=paintingObjectslist

    
    def getTotalPaintingprice(self,paintingtype):
        isMatch=False
        sum=0

        for i in range(len(self.paintinglist)):
            
            if self.paintinglist[i].paintingType==paintingtype:
                isMatch=True
                
                sum=sum+self.paintinglist[i].paintingPrice

        if isMatch==True:
            return sum
        else:
            return "No found"

    def getPainterWithMaxCountOfPaintings(self):

        plist=[]
        s=""

        for i in range(len(self.paintinglist)):
            k=i+1
            for j in range(k,len(self.paintinglist)):
                if self.paintinglist[i].painterName==self.paintinglist[j].painterName and self.paintinglist[i].painterName not in plist and self.paintinglist[i].paintingType==self.paintinglist[j].paintingType:
                   plist.append(self.paintinglist[i].painterName)
                   s=s+self.paintinglist[i].painterName

        
        return s


n=int(input())

paintinglist=[]

for i in range(n):
    pId=input()
    pname=input()
    pprice=int(input())
    ptype=input()

    pq=painting(pId,pname,pprice,ptype)
    paintinglist.append(pq)

s1=ShowRoom(paintinglist)


ptype=input()

print(s1.getTotalPaintingprice(ptype))
print(s1.getPainterWithMaxCountOfPaintings())

